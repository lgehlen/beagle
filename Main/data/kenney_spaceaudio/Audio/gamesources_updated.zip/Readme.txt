All graphics in these game sources were made by Kenney and can be downloaded for free (license: CC0, public domain)
at www.kenney.nl. You can also purchase bundles which contain thousands of assets: https://kenney.nl/store

These source files can be opened using the free version of Construct 2 or Construct 3.
Construct is a game engine which allows everyone to create games for a wide variety of platforms.

You can try Construct 3 for free at:
https://editor.construct.net/